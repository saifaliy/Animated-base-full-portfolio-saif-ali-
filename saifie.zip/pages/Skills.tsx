
import React from 'react';
import SectionHeader from '../components/SectionHeader';
import { SKILLS } from '../constants';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, PolarRadiusAxis } from 'recharts';

const Skills: React.FC = () => {
  const categories = Array.from(new Set(SKILLS.map(s => s.category)));
  
  const radarData = SKILLS.map(s => ({
    subject: s.name,
    A: s.level,
    fullMark: 100,
  }));

  return (
    <div className="pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader title="Skill Architecture" subtitle="My Technical DNA" />

        {/* Radar Chart Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-24 items-center">
           <div className="lg:col-span-5">
              <h3 className="text-3xl font-black mb-6">Visual Matrix</h3>
              <p className="text-lg text-gray-400 leading-relaxed mb-8">
                My skills aren't just a list—they are a balanced ecosystem of engineering depth and creative intuition. I specialize in high-performance AI integration coupled with robust frontend architecture.
              </p>
              <div className="space-y-4">
                 <div className="flex items-center gap-4">
                   <div className="w-4 h-4 rounded bg-blue-500"></div>
                   <span className="text-sm font-bold">AI & ML Specialist</span>
                 </div>
                 <div className="flex items-center gap-4">
                   <div className="w-4 h-4 rounded bg-purple-500"></div>
                   <span className="text-sm font-bold">Full-Stack Architect</span>
                 </div>
              </div>
           </div>
           
           <div className="lg:col-span-7 h-[400px] glass rounded-[32px] border border-white/10 p-4">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                  <PolarGrid stroke="#ffffff10" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#9ca3af', fontSize: 10 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar
                    name="Skills"
                    dataKey="A"
                    stroke="#3b82f6"
                    fill="#3b82f6"
                    fillOpacity={0.6}
                  />
                </RadarChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* Detailed Breakdown */}
        {categories.map((cat, i) => (
          <div key={i} className="mb-20">
            <h3 className="text-2xl font-black mb-10 flex items-center gap-4">
              <span className="w-8 h-[2px] bg-blue-500"></span>
              {cat}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {SKILLS.filter(s => s.category === cat).map((skill, j) => (
                <div key={j} className="glass p-6 rounded-2xl border border-white/5 hover:border-blue-500/30 transition-all group">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold">{skill.name}</h4>
                    <span className="text-xs font-black text-blue-500">{skill.level}%</span>
                  </div>
                  <div className="w-full h-1 bg-white/5 rounded-full mb-4 overflow-hidden">
                    <div 
                      className="h-full bg-blue-600 group-hover:bg-blue-400 transition-all duration-700"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                  <p className="text-[10px] text-gray-500 leading-relaxed uppercase font-bold tracking-wider">
                    {skill.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Skills;
