
import React, { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { Mail, Linkedin, Github, Send, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: 'AI Research Inquiry', message: '' });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    
    try {
      const response = await fetch('https://formspree.io/f/mrsaifie.512@gmail.com', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json' 
        },
        body: JSON.stringify({
          ...formData,
          _subject: `Portfolio Contact: ${formData.subject} from ${formData.name}`
        }),
      });

      if (response.ok) {
        setStatus('success');
        setFormData({ name: '', email: '', subject: 'AI Research Inquiry', message: '' });
      } else {
        setStatus('error');
      }
    } catch (err) {
      console.error("API Connection Error:", err);
      setStatus('error');
    }
  };

  return (
    <div className="pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader title="Establish Neural Link" subtitle="Connection Terminal" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          <div className="lg:col-span-5 space-y-8">
            <h3 className="text-4xl font-black mb-8">Direct Channels</h3>
            <p className="text-lg text-gray-400 leading-relaxed mb-12">
              Ready to collaborate on global AI missions? All transmissions are routed via encrypted API directly to <span className="text-white font-bold underline decoration-blue-500 underline-offset-8 decoration-2">mrsaifie.512@gmail.com</span>.
            </p>

            <div className="space-y-4">
              <a href="mailto:mrsaifie.512@gmail.com" className="glass p-8 rounded-3xl border border-white/5 flex items-center gap-6 group hover:border-blue-500/40 transition-all block bg-white/[0.01]">
                <div className="w-14 h-14 bg-blue-600/10 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 transition-all duration-500 shadow-xl group-hover:shadow-blue-500/20">
                  <Mail className="w-6 h-6 text-blue-500 group-hover:text-white" />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 mb-1">Direct Secure Port</div>
                   <div className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">mrsaifie.512@gmail.com</div>
                </div>
              </a>
              
              <a href="https://linkedin.com/in/sai-ali" target="_blank" rel="noopener noreferrer" className="glass p-8 rounded-3xl border border-white/5 flex items-center gap-6 group hover:border-blue-500/40 transition-all block bg-white/[0.01]">
                <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center group-hover:bg-[#0077b5] transition-all duration-500">
                  <Linkedin className="w-6 h-6 text-gray-400 group-hover:text-white" />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 mb-1">LinkedIn Network</div>
                   <div className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">Connect on Professional Hub</div>
                </div>
              </a>
            </div>

            <div className="mt-12 p-8 glass rounded-[40px] border border-blue-500/10 bg-blue-600/5 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-10">
                 <ShieldCheck className="w-24 h-24" />
               </div>
               <h4 className="text-xl font-bold mb-4 flex items-center gap-2">
                 <ShieldCheck className="text-blue-500 w-5 h-5" /> API Transmission Security
               </h4>
               <p className="text-sm text-gray-500 leading-relaxed">Transmissions are secured using industry-standard SSL encryption. Your project data is handled with maximum privacy protocols.</p>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="glass p-12 rounded-[50px] border border-white/10 relative overflow-hidden bg-black/40 shadow-2xl">
               {status === 'success' ? (
                 <div className="py-20 text-center animate-in fade-in zoom-in duration-500">
                    <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-10 border border-green-500/30 shadow-2xl shadow-green-500/20">
                      <CheckCircle2 className="w-12 h-12 text-green-500" />
                    </div>
                    <h3 className="text-5xl font-black mb-4">Transmission Sent</h3>
                    <p className="text-xl text-gray-400 max-w-sm mx-auto">Your inquiry has been successfully routed to Saif's inbox. Expect a response shortly.</p>
                    <button onClick={() => setStatus('idle')} className="mt-12 px-10 py-4 bg-white/5 rounded-full text-blue-500 font-black uppercase tracking-widest hover:bg-white/10 transition-all border border-white/10">New Transmission</button>
                 </div>
               ) : (
                 <form onSubmit={handleSubmit} className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-3">
                          <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 ml-4">Full Identity</label>
                          <input 
                            required
                            name="name"
                            type="text" 
                            placeholder="e.g. Elon Musk"
                            value={formData.name}
                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                            className="w-full px-8 py-5 glass rounded-3xl border border-white/5 focus:border-blue-500 outline-none transition-all placeholder:text-gray-700"
                          />
                       </div>
                       <div className="space-y-3">
                          <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 ml-4">Email Terminal</label>
                          <input 
                            required
                            name="email"
                            type="email" 
                            placeholder="user@example.com"
                            value={formData.email}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                            className="w-full px-8 py-5 glass rounded-3xl border border-white/5 focus:border-blue-500 outline-none transition-all placeholder:text-gray-700"
                          />
                       </div>
                    </div>
                    
                    <div className="space-y-3">
                       <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 ml-4">Subject Parameter</label>
                       <select 
                         name="subject"
                         value={formData.subject}
                         onChange={(e) => setFormData({...formData, subject: e.target.value})}
                         className="w-full px-8 py-5 glass rounded-3xl border border-white/5 focus:border-blue-500 outline-none transition-all appearance-none text-white cursor-pointer"
                       >
                          <option className="bg-slate-900">AI Research Collaboration</option>
                          <option className="bg-slate-900">Enterprise Software Solution</option>
                          <option className="bg-slate-900">Custom Neural Systems</option>
                          <option className="bg-slate-900">General Consultation</option>
                       </select>
                    </div>

                    <div className="space-y-3">
                       <label className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 ml-4">Project Synthesis</label>
                       <textarea 
                         required
                         name="message"
                         rows={5} 
                         placeholder="Briefly describe your mission requirements..."
                         value={formData.message}
                         onChange={(e) => setFormData({...formData, message: e.target.value})}
                         className="w-full px-8 py-5 glass rounded-3xl border border-white/5 focus:border-blue-500 outline-none transition-all resize-none placeholder:text-gray-700"
                       ></textarea>
                    </div>

                    {status === 'error' && (
                      <div className="flex items-center gap-4 text-red-500 font-bold glass p-6 rounded-3xl border border-red-500/20 bg-red-500/5">
                        <AlertCircle className="w-6 h-6" /> Transmission node failure. Check connection and retry.
                      </div>
                    )}

                    <button 
                      disabled={status === 'sending'}
                      className="w-full py-7 bg-gradient-to-r from-blue-600 to-blue-800 rounded-[2.5rem] font-black text-xl flex items-center justify-center gap-4 hover:shadow-[0_0_50px_rgba(59,130,246,0.5)] transition-all disabled:opacity-30 disabled:cursor-not-allowed group/btn"
                    >
                      {status === 'sending' ? (
                        <div className="flex items-center gap-3">
                           <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                           <span>Broadcasting...</span>
                        </div>
                      ) : (
                        <>Route Transmission <Send className="w-6 h-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /></>
                      )}
                    </button>
                 </form>
               )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
